# Comparación entre LDA y QDA utilizando el Wine Dataset

## Descripción del proyecto

Este proyecto compara el desempeño del **Análisis Discriminante Lineal (LDA)** y el **Análisis Discriminante Cuadrático (QDA)** utilizando el Wine Dataset incluido en la biblioteca Scikit-learn. El objetivo es analizar las diferencias entre ambos modelos de clasificación supervisada mediante métricas de evaluación y la representación de sus fronteras de decisión.

## Objetivos

* Investigar los fundamentos teóricos de LDA y QDA.
* Implementar ambos modelos en Python utilizando Google Colab.
* Comparar el desempeño de los algoritmos mediante diferentes métricas.
* Analizar las fronteras de decisión generadas por cada modelo.

## Conjunto de datos

Se utilizó el **Wine Dataset** disponible en Scikit-learn.

Características principales:

* Número de observaciones: **178**
* Variables predictoras: **13**
* Variable objetivo: **Clase**
* Número de clases: **3**
* Valores faltantes: **0**

El conjunto de datos contiene mediciones químicas de diferentes tipos de vino y es ampliamente utilizado para problemas de clasificación.

## Librerías utilizadas

* Python 3
* Google Colab
* NumPy
* Pandas
* Matplotlib
* Seaborn
* Scikit-learn

## Estructura del proyecto

```text
Tarea Análisis Discriminante LDA y QDA/
│
├── Análisis Discriminante (LDA y QDA) - Correa Preciado Jonathan Alexi.ipynb
├── README.md
└── U4 S14 Tarea Análisis Discriminante LDA y QDA - Correa Preciado Jonathan Alexi.pdf
```

## Cómo ejecutar el proyecto

1. Clonar el repositorio:

```bash
[git clone https://github.com/USUARIO/NOMBRE_DEL_REPOSITORIO.git](https://colab.research.google.com/drive/13PsrL-el81yVaYNbUnwvoeFtrQajELfL?usp=sharing)
```

2. Abrir el archivo `Análisis Discriminante (LDA y QDA) - Correa Preciado Jonathan Alexi` en Google Colab o Jupyter Notebook.

3. Ejecutar las celdas en orden, desde la primera hasta la última.

4. El notebook generará automáticamente:

   * Descripción del conjunto de datos.
   * Exploración de los datos
   * Visualizaciones.
   * Preparación de los datos
   * Implementación de LDA.
   * Implementación de QDA.
   * Comparación de modelos.
   * Fronteras  de decisióm.

## Resultados principales

Durante el desarrollo del proyecto se obtuvo un excelente desempeño tanto para LDA como para QDA sobre el Wine Dataset. Ambos modelos lograron clasificar correctamente la mayoría de las observaciones del conjunto de prueba.

La comparación mostró que LDA utiliza fronteras de decisión lineales debido al supuesto de una matriz de covarianza común entre las clases, mientras que QDA genera fronteras cuadráticas al estimar una matriz de covarianza diferente para cada clase. Dependiendo de la distribución de los datos, uno de los modelos puede ofrecer un desempeño ligeramente superior.

## Autor

Jonathan Alexi Correa Preciado
